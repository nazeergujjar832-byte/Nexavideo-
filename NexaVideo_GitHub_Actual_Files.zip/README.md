# NexaVideo - FINAL ORIGINAL SOURCE (No APK)
This is 100% original source code as per Final Project Documentation.
- Open android/ folder in Android Studio
- Backend: cd backend && docker-compose up --build
Location: Gujranwala, Punjab - Nazeer Gujjar
