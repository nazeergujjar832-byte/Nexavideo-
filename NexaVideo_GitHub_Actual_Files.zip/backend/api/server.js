const express=require('express'); const app=express(); app.use(express.json());
app.get('/health',(req,res)=>res.json({status:'ok', project:'NexaVideo Final Original'}));
app.get('/api/feed',(req,res)=>res.json([{id:1,title:'Home Feed Ready'},{id:2,title:'Shorts Ready'}]));
app.post('/api/auth/login',(req,res)=>res.json({token:'JWT', user:{id:1,name:'Nazeer'}}));
app.listen(3000,()=>console.log('API running 3000'));
