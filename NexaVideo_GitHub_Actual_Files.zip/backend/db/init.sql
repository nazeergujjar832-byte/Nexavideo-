CREATE TABLE users (id SERIAL PRIMARY KEY, email TEXT UNIQUE, created_at TIMESTAMP DEFAULT NOW());
CREATE TABLE videos (id SERIAL PRIMARY KEY, user_id INT, title TEXT, likes INT DEFAULT 0);
CREATE TABLE likes (id SERIAL PRIMARY KEY, user_id INT, video_id INT);
CREATE TABLE follows (id SERIAL PRIMARY KEY, follower_id INT, following_id INT);
CREATE TABLE comments (id SERIAL PRIMARY KEY, video_id INT, text TEXT);
CREATE TABLE creator_ledger (id SERIAL PRIMARY KEY, creator_id INT, earning DECIMAL);
