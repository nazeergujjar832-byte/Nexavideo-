package com.nexavideo.ui
import android.os.Bundle; import androidx.appcompat.app.AppCompatActivity; import androidx.viewpager2.widget.ViewPager2; import androidx.recyclerview.widget.RecyclerView; import android.view.*; import android.widget.*; import com.nexavideo.R
class MainActivity : AppCompatActivity() {
  override fun onCreate(s: Bundle?) { super.onCreate(s); setContentView(R.layout.activity_main); findViewById<ViewPager2>(R.id.viewPager).adapter = VideoAdapter() }
  class VideoAdapter : RecyclerView.Adapter<VideoAdapter.VH>() {
    val videos = listOf("Home Feed - Backend API Ready","Shorts API - Navigation Ready","Video Upload - MVP Local Ready","Likes/Follows/Comments/Saves - DB Ready","Inbox/Messaging Core Ready","Notifications Foundation Ready","Profile/Creator Ledger Ready","Search API Ready","Docker+PostgreSQL+API Dev Setup Ready","GitHub Actions Build Ready - Gujranwala")
    class VH(v: View) : RecyclerView.ViewHolder(v) { val title: TextView = v.findViewById(R.id.videoTitle) }
    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(LayoutInflater.from(p.context).inflate(R.layout.item_video, p, false))
    override fun onBindViewHolder(h: VH, pos: Int) { h.title.text = videos[pos] }
    override fun getItemCount() = videos.size
  }
}
