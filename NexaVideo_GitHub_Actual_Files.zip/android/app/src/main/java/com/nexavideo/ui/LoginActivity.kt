package com.nexavideo.ui
import android.content.Intent; import android.os.Bundle; import androidx.appcompat.app.AppCompatActivity; import android.widget.Button; import com.nexavideo.R
class LoginActivity : AppCompatActivity() {
  override fun onCreate(s: Bundle?) { super.onCreate(s); setContentView(R.layout.activity_login); findViewById<Button>(R.id.btnLogin).setOnClickListener { startActivity(Intent(this, MainActivity::class.java)) } }
}
