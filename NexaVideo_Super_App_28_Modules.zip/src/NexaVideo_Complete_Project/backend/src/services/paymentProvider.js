// Provider-neutral payment/payout boundary for Step 4.
// Real money movement must be implemented with a verified payment provider.
function createPaymentProvider(config = {}) {
  return {
    name: config.name || process.env.PAYMENT_PROVIDER || 'unconfigured',
    async createPayout() {
      throw new Error('payment_provider_not_configured');
    },
    async verifyWebhook() {
      throw new Error('payment_provider_not_configured');
    }
  };
}
module.exports = { createPaymentProvider };
