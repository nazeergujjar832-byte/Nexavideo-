const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const multer = require('multer');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { z } = require('zod');
const createAiRoutes = require('./routes/ai');

const app = express();
const port = Number(process.env.PORT || 8080);
const isProduction = process.env.NODE_ENV === 'production';
const jwtSecret = process.env.JWT_SECRET || (isProduction ? '' : 'dev-only-change-this-secret');
const refreshSecret = process.env.REFRESH_SECRET || (isProduction ? '' : 'dev-only-change-this-refresh-secret');
if (isProduction && (!jwtSecret || !refreshSecret || jwtSecret.length < 32 || refreshSecret.length < 32)) { throw new Error('Production JWT_SECRET and REFRESH_SECRET must each be at least 32 characters.'); }
const pool = new Pool({ connectionString: process.env.DATABASE_URL || 'postgres://nexavideo:nexavideo@localhost:5432/nexavideo' });
const uploadDir = process.env.UPLOAD_DIR || '/tmp/nexavideo';
fs.mkdirSync(uploadDir, { recursive: true });
const publicBaseUrl = (process.env.PUBLIC_BASE_URL || '').replace(/\/$/, '');
const upload = multer({ dest: uploadDir, limits: { fileSize: 2 * 1024 * 1024 * 1024 }, fileFilter: (_req, file, cb) => { if (!file.mimetype.startsWith('video/')) return cb(new Error('video_file_required')); cb(null, true); } });

app.use(helmet());
const allowedOrigins = (process.env.CORS_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean);
if (isProduction && (!allowedOrigins.length || allowedOrigins.includes('*'))) { throw new Error('Production CORS_ORIGIN must contain one or more explicit HTTPS origins; wildcard is not allowed.'); }
app.use(cors({ origin: allowedOrigins.length ? allowedOrigins : (isProduction ? false : true), credentials: true }));
app.use(express.json({ limit: '2mb' }));
app.use('/uploads', express.static(uploadDir, { maxAge: '1h', immutable: false }));
const generalLimiter = rateLimit({ windowMs: 60_000, max: 120, standardHeaders: true, legacyHeaders: false });
const authLimiter = rateLimit({ windowMs: 15 * 60_000, max: 20, standardHeaders: true, legacyHeaders: false });
app.use(generalLimiter);

function accessToken(user) { return jwt.sign({ sub: user.id, username: user.username, accountType: user.account_type || user.accountType || 'USER' }, jwtSecret, { expiresIn: '15m' }); }
function refreshToken(user) { return jwt.sign({ sub: user.id, type: 'refresh' }, refreshSecret, { expiresIn: '30d' }); }
function auth(req, res, next) {
  const raw = req.headers.authorization || '';
  const token = raw.startsWith('Bearer ') ? raw.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'authentication_required' });
  try { req.user = jwt.verify(token, jwtSecret); next(); } catch { return res.status(401).json({ error: 'invalid_or_expired_token' }); }
}
function requireAdmin(req, res, next) {
  if (req.user?.accountType !== 'ADMIN') return res.status(403).json({ error: 'admin_required' });
  next();
}
function validate(schema, source='body') { return (req, res, next) => { const parsed = schema.safeParse(req[source]); if (!parsed.success) return res.status(400).json({ error: 'validation_error', details: parsed.error.flatten() }); req[source] = parsed.data; next(); }; }
const credentials = z.object({ username: z.string().min(3).max(32).regex(/^[a-zA-Z0-9_.-]+$/), password: z.string().min(8).max(128), email: z.string().email().optional() });

app.disable('x-powered-by');
app.use('/api/v1/ai', createAiRoutes({ pool, auth, validate }));
app.get('/health', async (_req, res) => { try { await pool.query('SELECT 1'); res.json({ ok: true, service: 'nexavideo-api', database: 'ok' }); } catch { res.status(503).json({ ok: false, service: 'nexavideo-api', database: 'unavailable' }); } });

app.post('/api/v1/auth/register', authLimiter, validate(credentials), async (req, res) => {
  const { username, password, email } = req.body;
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query('INSERT INTO users(username,email,password_hash) VALUES($1,$2,$3) RETURNING id,username,email,created_at', [username, email || null, hash]);
    const user = result.rows[0];
    await pool.query('INSERT INTO profiles(user_id,display_name) VALUES($1,$2) ON CONFLICT DO NOTHING', [user.id, username]);
    res.status(201).json({ user, accessToken: accessToken(user), refreshToken: refreshToken(user) });
  } catch (e) { if (e.code === '23505') return res.status(409).json({ error: 'username_or_email_already_exists' }); res.status(500).json({ error: 'registration_failed' }); }
});

app.post('/api/v1/auth/login', authLimiter, validate(z.object({ username: z.string().min(1), password: z.string().min(1) })), async (req, res) => {
  const r = await pool.query('SELECT id,username,email,password_hash,status,account_type FROM users WHERE username=$1 OR email=$1 LIMIT 1', [req.body.username]);
  const user = r.rows[0];
  if (!user || user.status !== 'ACTIVE' || !user.password_hash || !(await bcrypt.compare(req.body.password, user.password_hash))) return res.status(401).json({ error: 'invalid_credentials' });
  res.json({ user: { id:user.id, username:user.username, email:user.email, accountType:user.account_type }, accessToken: accessToken(user), refreshToken: refreshToken(user) });
});

app.post('/api/v1/auth/refresh', validate(z.object({ refreshToken: z.string().min(1) })), async (req,res) => { try { const p=jwt.verify(req.body.refreshToken, refreshSecret); if(p.type!=='refresh') throw new Error(); const r=await pool.query('SELECT id,username,email FROM users WHERE id=$1 AND status=\'ACTIVE\'', [p.sub]); if(!r.rows[0]) return res.status(401).json({error:'user_not_found'}); res.json({accessToken:accessToken(r.rows[0])}); } catch { res.status(401).json({error:'invalid_refresh_token'}); } });
app.get('/api/v1/me', auth, async (req,res) => { const r=await pool.query(`SELECT u.id,u.username,u.email,p.display_name,p.avatar_url,p.bio,p.country,p.language FROM users u LEFT JOIN profiles p ON p.user_id=u.id WHERE u.id=$1`, [req.user.sub]); res.json(r.rows[0] || null); });

app.get('/api/v1/feed', async (req,res) => {
  const limit=Math.min(Math.max(Number(req.query.limit||20),1),50); const cursor=req.query.cursor||null;
  const params=cursor?[cursor,limit]:[limit]; const where=cursor?'AND v.created_at < $1':''; const lim=cursor?'$2':'$1';
  const r=await pool.query(`SELECT v.id,v.title,v.description,v.thumbnail_url,v.playback_url,v.duration_seconds,v.views,v.likes,v.comments_count,v.created_at,u.id creator_id,u.username,p.display_name,p.avatar_url FROM videos v JOIN users u ON u.id=v.creator_id LEFT JOIN profiles p ON p.user_id=u.id WHERE v.visibility='PUBLIC' AND v.processing_status='READY' ${where} ORDER BY v.created_at DESC LIMIT ${lim}`,params);
  res.json({items:r.rows,nextCursor:r.rows.length? r.rows[r.rows.length-1].created_at:null});
});

app.post('/api/v1/videos/upload-session', auth, validate(z.object({ title:z.string().min(1).max(150), description:z.string().max(5000).optional(), durationSeconds:z.number().int().nonnegative().optional(), visibility:z.enum(['PUBLIC','UNLISTED','PRIVATE']).default('PUBLIC') })), async(req,res)=>{
  const id=crypto.randomUUID(); await pool.query('INSERT INTO videos(id,creator_id,title,description,duration_seconds,visibility,processing_status) VALUES($1,$2,$3,$4,$5,$6,\'UPLOADING\')',[id,req.user.sub,req.body.title,req.body.description||null,req.body.durationSeconds||null,req.body.visibility]);
  res.status(201).json({ videoId:id, uploadUrl:`/api/v1/videos/${id}/upload`, expiresInSeconds:3600 });
});
app.post('/api/v1/videos/:id/upload', auth, upload.single('video'), async(req,res)=>{
  const r=await pool.query('SELECT creator_id FROM videos WHERE id=$1',[req.params.id]);
  if(!r.rows[0]||r.rows[0].creator_id!==req.user.sub)return res.status(404).json({error:'video_not_found'});
  if(!req.file)return res.status(400).json({error:'video_file_required'});
  const ext = path.extname(req.file.originalname).replace(/[^a-zA-Z0-9.]/g,'').slice(0,10) || '.mp4';
  const finalName = `${req.params.id}-${crypto.randomUUID()}${ext}`;
  const finalPath = path.join(uploadDir, finalName);
  fs.renameSync(req.file.path, finalPath);
  const playbackUrl = `${publicBaseUrl}/uploads/${encodeURIComponent(finalName)}`;
  await pool.query('UPDATE videos SET original_file=$1,playback_url=$2,processing_status=\'READY\',published_at=now() WHERE id=$3',[finalPath,playbackUrl,req.params.id]);
  res.json({ok:true,processingStatus:'READY',playbackUrl});
});

app.post('/api/v1/videos/:id/view', async(req,res)=>{ await pool.query('UPDATE videos SET views=views+1 WHERE id=$1',[req.params.id]); res.status(204).end(); });
app.post('/api/v1/videos/:id/like', auth, async(req,res)=>{ const c=await pool.query('INSERT INTO video_likes(user_id,video_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.user.sub,req.params.id]); if(c.rowCount) await pool.query('UPDATE videos SET likes=likes+1 WHERE id=$1',[req.params.id]); res.json({liked:true}); });
app.delete('/api/v1/videos/:id/like', auth, async(req,res)=>{ const c=await pool.query('DELETE FROM video_likes WHERE user_id=$1 AND video_id=$2',[req.user.sub,req.params.id]); if(c.rowCount) await pool.query('UPDATE videos SET likes=GREATEST(likes-1,0) WHERE id=$1',[req.params.id]); res.status(204).end(); });
app.post('/api/v1/videos/:id/comments', auth, validate(z.object({text:z.string().min(1).max(2000)})), async(req,res)=>{ const r=await pool.query('INSERT INTO comments(video_id,user_id,text) VALUES($1,$2,$3) RETURNING *',[req.params.id,req.user.sub,req.body.text]); await pool.query('UPDATE videos SET comments_count=comments_count+1 WHERE id=$1',[req.params.id]); res.status(201).json(r.rows[0]); });
app.get('/api/v1/videos/:id/comments', async(req,res)=>{ const r=await pool.query(`SELECT c.id,c.text,c.created_at,u.username,p.display_name,p.avatar_url FROM comments c JOIN users u ON u.id=c.user_id LEFT JOIN profiles p ON p.user_id=u.id WHERE c.video_id=$1 AND c.status='VISIBLE' ORDER BY c.created_at ASC LIMIT 100`,[req.params.id]); res.json(r.rows); });

app.post('/api/v1/users/:id/follow', auth, async(req,res)=>{ if(req.params.id===req.user.sub)return res.status(400).json({error:'cannot_follow_self'}); const c=await pool.query('INSERT INTO follows(follower_id,following_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.user.sub,req.params.id]); if(c.rowCount) await pool.query(`INSERT INTO notifications(user_id,type,payload) VALUES($1,'FOLLOW',jsonb_build_object('actorId',$2))`,[req.params.id,req.user.sub]); res.json({following:true}); });
app.delete('/api/v1/users/:id/follow', auth, async(req,res)=>{ await pool.query('DELETE FROM follows WHERE follower_id=$1 AND following_id=$2',[req.user.sub,req.params.id]); res.status(204).end(); });

app.get('/api/v1/notifications', auth, async(req,res)=>{ const r=await pool.query('SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100',[req.user.sub]); res.json(r.rows); });
app.post('/api/v1/notifications/read-all', auth, async(req,res)=>{ await pool.query('UPDATE notifications SET read_at=now() WHERE user_id=$1 AND read_at IS NULL',[req.user.sub]); res.status(204).end(); });
app.get('/api/v1/messages/:userId', auth, async(req,res)=>{ const r=await pool.query(`SELECT * FROM messages WHERE (sender_id=$1 AND recipient_id=$2) OR (sender_id=$2 AND recipient_id=$1) ORDER BY created_at ASC LIMIT 200`,[req.user.sub,req.params.userId]); res.json(r.rows); });
app.post('/api/v1/messages/:userId', auth, validate(z.object({body:z.string().min(1).max(5000)})), async(req,res)=>{ const r=await pool.query('INSERT INTO messages(sender_id,recipient_id,body) VALUES($1,$2,$3) RETURNING *',[req.user.sub,req.params.userId,req.body.body]); await pool.query(`INSERT INTO notifications(user_id,type,payload) VALUES($1,'MESSAGE',jsonb_build_object('senderId',$2))`,[req.params.userId,req.user.sub]); res.status(201).json(r.rows[0]); });

app.get('/api/v1/search', async(req,res)=>{ const q=String(req.query.q||'').trim(); if(q.length<2)return res.json({videos:[],creators:[]}); const like=`%${q}%`; const [v,u]=await Promise.all([pool.query(`SELECT id,title,thumbnail_url,playback_url,views FROM videos WHERE visibility='PUBLIC' AND processing_status='READY' AND (title ILIKE $1 OR description ILIKE $1) ORDER BY views DESC LIMIT 30`,[like]),pool.query(`SELECT u.id,u.username,p.display_name,p.avatar_url FROM users u LEFT JOIN profiles p ON p.user_id=u.id WHERE u.username ILIKE $1 OR p.display_name ILIKE $1 LIMIT 30`,[like])]); res.json({videos:v.rows,creators:u.rows}); });


app.get('/api/v1/shorts', async (_req,res)=>{ const r=await pool.query("SELECT id,video_url,thumbnail_url,title,duration_seconds,views FROM shorts WHERE visibility='PUBLIC' ORDER BY created_at DESC LIMIT 50"); res.json(r.rows); });
app.post('/api/v1/shorts/:id/view', async(req,res)=>{await pool.query('UPDATE shorts SET views=views+1 WHERE id=$1',[req.params.id]);res.status(204).end();});
app.post('/api/v1/videos/:id/watch', async(req,res)=>{const seconds=Math.max(0,Math.min(Number(req.body.watchSeconds||0),86400));await pool.query('INSERT INTO video_views(video_id,viewer_id,watch_seconds,session_id) VALUES($1,$2,$3,$4)',[req.params.id,req.user?.sub||null,seconds,req.body.sessionId||null]).catch(()=>{});res.status(204).end();});
app.post('/api/v1/videos/:id/save', auth, async(req,res)=>{await pool.query('INSERT INTO saved_videos(user_id,video_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.user.sub,req.params.id]);res.json({saved:true});});
app.delete('/api/v1/videos/:id/save', auth, async(req,res)=>{await pool.query('DELETE FROM saved_videos WHERE user_id=$1 AND video_id=$2',[req.user.sub,req.params.id]);res.status(204).end();});
app.get('/api/v1/me/saved', auth, async(req,res)=>{const r=await pool.query(`SELECT v.* FROM saved_videos s JOIN videos v ON v.id=s.video_id WHERE s.user_id=$1 ORDER BY s.created_at DESC`,[req.user.sub]);res.json(r.rows);});
app.patch('/api/v1/me', auth, validate(z.object({displayName:z.string().max(80).optional(),bio:z.string().max(500).optional(),avatarUrl:z.string().url().optional(),country:z.string().max(80).optional(),language:z.string().max(20).optional()})), async(req,res)=>{const b=req.body;await pool.query(`INSERT INTO profiles(user_id,display_name,bio,avatar_url,country,language) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(user_id) DO UPDATE SET display_name=COALESCE($2,profiles.display_name),bio=COALESCE($3,profiles.bio),avatar_url=COALESCE($4,profiles.avatar_url),country=COALESCE($5,profiles.country),language=COALESCE($6,profiles.language),updated_at=now()`,[req.user.sub,b.displayName||null,b.bio||null,b.avatarUrl||null,b.country||null,b.language||null]);const r=await pool.query(`SELECT u.id,u.username,u.email,p.display_name,p.avatar_url,p.bio,p.country,p.language FROM users u LEFT JOIN profiles p ON p.user_id=u.id WHERE u.id=$1`,[req.user.sub]);res.json(r.rows[0]);});
app.get('/api/v1/creator/stats', auth, async(req,res)=>{const [v,e,f]=await Promise.all([pool.query('SELECT COUNT(*)::int videos,COALESCE(SUM(views),0)::bigint views,COALESCE(SUM(likes),0)::bigint likes FROM videos WHERE creator_id=$1',[req.user.sub]),pool.query("SELECT COALESCE(SUM(amount_minor),0)::bigint earnings FROM earnings_ledger WHERE creator_id=$1 AND status='CONFIRMED'",[req.user.sub]),pool.query('SELECT COUNT(*)::int followers FROM follows WHERE following_id=$1',[req.user.sub])]);res.json({...v.rows[0],...e.rows[0],...f.rows[0]});});
app.post('/api/v1/creator/enable', auth, async(req,res)=>{const r=await pool.query(`INSERT INTO creator_accounts(user_id,status) VALUES($1,'PENDING') ON CONFLICT(user_id) DO UPDATE SET status='PENDING' RETURNING *`,[req.user.sub]);res.status(201).json(r.rows[0]);});
app.post('/api/v1/reports', auth, validate(z.object({targetType:z.string().min(1).max(40),targetId:z.string().uuid(),reason:z.string().min(2).max(500)})), async(req,res)=>{const r=await pool.query('INSERT INTO reports(reporter_id,target_type,target_id,reason) VALUES($1,$2,$3,$4) RETURNING id,status,created_at',[req.user.sub,req.body.targetType,req.body.targetId,req.body.reason]);res.status(201).json(r.rows[0]);});
app.get('/api/v1/search/suggestions', async(req,res)=>{const q=String(req.query.q||'').trim();if(q.length<1)return res.json([]);const r=await pool.query(`SELECT username FROM users WHERE username ILIKE $1 ORDER BY username LIMIT 10`,[`%${q}%`]);res.json(r.rows.map(x=>x.username));});
app.get('/api/v1/health/details', async(_req,res)=>{const r=await pool.query('SELECT now() as server_time');res.json({service:'NexaVideo',api:'ok',database:'ok',serverTime:r.rows[0].server_time,version:'0.4.0'});});



const AI_TOOL_CATALOG = [
  {id:'video.auto_cut',name:'Auto Cut',category:'Video',input:'video',status:'provider_ready'},
  {id:'video.smart_trim',name:'Smart Trim',category:'Video',input:'video',status:'provider_ready'},
  {id:'video.highlights',name:'Highlight Maker',category:'Video',input:'video',status:'provider_ready'},
  {id:'video.to_shorts',name:'Long Video to Shorts',category:'Video',input:'video',status:'provider_ready'},
  {id:'video.scene_detect',name:'Scene Detection',category:'Video',input:'video',status:'provider_ready'},
  {id:'video.auto_reframe',name:'Auto Reframe',category:'Video',input:'video',status:'provider_ready'},
  {id:'video.tracking',name:'Subject Tracking',category:'Video',input:'video',status:'provider_ready'},
  {id:'video.background',name:'Background Remove/Replace',category:'Video',input:'video',status:'provider_ready'},
  {id:'video.object_remove',name:'Object Removal',category:'Video',input:'video',status:'provider_ready'},
  {id:'video.enhance',name:'Video Enhancement/Upscale',category:'Video',input:'video',status:'provider_ready'},
  {id:'video.captions',name:'Auto Captions',category:'Video',input:'video',status:'provider_ready'},
  {id:'video.translate',name:'Subtitle Translation',category:'Video',input:'video',status:'provider_ready'},
  {id:'video.dub',name:'AI Dubbing',category:'Video',input:'video',status:'provider_ready'},
  {id:'video.storyboard',name:'Script to Storyboard',category:'Generative Video',input:'text',status:'provider_ready'},
  {id:'video.text_to_video',name:'Text to Video',category:'Generative Video',input:'text',status:'provider_ready'},
  {id:'video.image_to_video',name:'Image to Video',category:'Generative Video',input:'image',status:'provider_ready'},
  {id:'image.generate',name:'AI Image Generator',category:'Design',input:'text',status:'provider_ready'},
  {id:'image.thumbnail',name:'Thumbnail Generator',category:'Design',input:'text',status:'provider_ready'},
  {id:'image.poster',name:'Poster Generator',category:'Design',input:'text',status:'provider_ready'},
  {id:'image.background',name:'Background Generator',category:'Design',input:'image',status:'provider_ready'},
  {id:'image.erase',name:'Object Eraser',category:'Design',input:'image',status:'provider_ready'},
  {id:'image.upscale',name:'Image Upscale',category:'Design',input:'image',status:'provider_ready'},
  {id:'audio.stt',name:'Speech to Text',category:'Audio',input:'audio',status:'provider_ready'},
  {id:'audio.tts',name:'Text to Speech',category:'Audio',input:'text',status:'provider_ready'},
  {id:'audio.voiceover',name:'AI Voice-over',category:'Audio',input:'text',status:'provider_ready'},
  {id:'audio.cleanup',name:'Voice/Noise Cleanup',category:'Audio',input:'audio',status:'provider_ready'},
  {id:'writing.script',name:'Script Writer',category:'Writing',input:'text',status:'provider_ready'},
  {id:'writing.hook',name:'Hook Generator',category:'Writing',input:'text',status:'provider_ready'},
  {id:'writing.caption',name:'Caption Generator',category:'Writing',input:'text',status:'provider_ready'},
  {id:'writing.title',name:'Title Generator',category:'Writing',input:'text',status:'provider_ready'},
  {id:'writing.hashtags',name:'Hashtag Generator',category:'Writing',input:'text',status:'provider_ready'},
  {id:'writing.translate',name:'AI Translation',category:'Writing',input:'text',status:'provider_ready'},
  {id:'creator.copilot',name:'Creator Copilot',category:'Creator Intelligence',input:'mixed',status:'provider_ready'},
  {id:'creator.analytics',name:'Content Performance Assistant',category:'Creator Intelligence',input:'analytics',status:'provider_ready'},
  {id:'safety.moderation',name:'AI Content Moderation',category:'Safety',input:'mixed',status:'provider_ready'},
  {id:'safety.spam',name:'Spam/Abuse Detection',category:'Safety',input:'text',status:'provider_ready'}
];
app.get('/api/v1/ai/tools', (_req,res) => res.json({version:'1.0', providerBoundary:true, tools:AI_TOOL_CATALOG}));
app.post('/api/v1/ai/jobs', auth, validate(z.object({toolId:z.string().min(3).max(80), input:z.record(z.any()).default({})})), async(req,res)=>{
  const tool=AI_TOOL_CATALOG.find(x=>x.id===req.body.toolId);
  if(!tool) return res.status(404).json({error:'ai_tool_not_found'});
  res.status(202).json({jobId:null,status:'PROVIDER_REQUIRED',tool, message:'AI provider/worker is not configured yet. Connect a provider on the backend before enabling generation.'});
});

app.get('/api/v1/admin/reports', auth, requireAdmin, async (req,res) => {
  const limit=Math.min(Math.max(Number(req.query.limit||50),1),100);
  const r=await pool.query(`SELECT id,reporter_id,target_type,target_id,reason,status,created_at FROM reports ORDER BY created_at DESC LIMIT $1`,[limit]);
  res.json(r.rows);
});
app.patch('/api/v1/admin/reports/:id', auth, requireAdmin, validate(z.object({status:z.enum(['OPEN','REVIEWING','RESOLVED','REJECTED']), action:z.string().max(80).optional()})), async(req,res) => {
  const r=await pool.query('UPDATE reports SET status=$1 WHERE id=$2 RETURNING *',[req.body.status,req.params.id]);
  if(!r.rows[0]) return res.status(404).json({error:'report_not_found'});
  await pool.query('INSERT INTO moderation_actions(moderator_id,target_type,target_id,action,reason) VALUES($1,$2,$3,$4,$5)',[req.user.sub,'REPORT',r.rows[0].id,req.body.action||req.body.status,null]).catch(()=>{});
  res.json(r.rows[0]);
});
app.get('/api/v1/admin/health', auth, requireAdmin, async (_req,res) => {
  const r=await pool.query('SELECT now() as server_time, (SELECT count(*) FROM users)::int as users, (SELECT count(*) FROM videos)::int as videos');
  res.json({ok:true,serverTime:r.rows[0].server_time,users:r.rows[0].users,videos:r.rows[0].videos});
});

app.use((err,_req,res,_next)=>{ console.error(err); if(err.code==='LIMIT_FILE_SIZE') return res.status(413).json({error:'file_too_large'}); if(err.message==='video_file_required') return res.status(415).json({error:'video_file_required'}); res.status(500).json({error:'internal_server_error'}); });
app.listen(port,()=>console.log(`NexaVideo API listening on :${port}`));
