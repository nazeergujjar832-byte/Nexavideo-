# Retrofit/Gson models are accessed reflectively. Keep model fields and annotations.
-keepattributes RuntimeVisibleAnnotations,RuntimeInvisibleAnnotations,AnnotationDefault
-keep class com.nexavideo.data.** { *; }
-dontwarn javax.annotation.**
