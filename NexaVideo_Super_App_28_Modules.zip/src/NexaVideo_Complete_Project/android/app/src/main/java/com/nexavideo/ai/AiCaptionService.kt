package com.nexavideo.ai

/**
 * AI integration boundary for NexaVideo.
 * A real on-device or cloud provider can be plugged in later without changing UI code.
 */
interface AiCaptionService {
    suspend fun suggestCaption(title: String, description: String): String
}

class LocalCaptionService : AiCaptionService {
    override suspend fun suggestCaption(title: String, description: String): String {
        val base = title.trim().ifBlank { "NexaVideo" }
        return if (description.isBlank()) "$base — watch, like and share!" else "$base — ${description.trim()}"
    }
}
