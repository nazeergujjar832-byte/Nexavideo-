package com.nexavideo

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nexavideo.data.*
import com.nexavideo.ai.AiCaptionService
import com.nexavideo.ai.LocalCaptionService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okio.BufferedSink
import java.io.IOException

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexaVideoApp() }
    }
}

class AppViewModel : ViewModel() {
    private val ai: AiCaptionService = LocalCaptionService()
    var loggedIn by mutableStateOf(false); private set
    var user by mutableStateOf<User?>(null); private set
    var videos by mutableStateOf<List<Video>>(emptyList()); private set
    var shorts by mutableStateOf<List<ShortItem>>(emptyList()); private set
    var error by mutableStateOf<String?>(null); private set
    var status by mutableStateOf<String?>(null); private set

    fun login(username: String, password: String) = call {
        val r = ApiClient.api.login(AuthRequest(username, password))
        Session.token = r.accessToken
        Session.refreshToken = r.refreshToken
        user = r.user
        loggedIn = true
        loadFeed()
    }

    fun register(username: String, password: String, email: String?) = call {
        val r = ApiClient.api.register(AuthRequest(username, password, email))
        Session.token = r.accessToken
        Session.refreshToken = r.refreshToken
        user = r.user
        loggedIn = true
        loadFeed()
    }

    fun loadFeed() = call { videos = ApiClient.api.feed().items }
    fun loadShorts() = call { shorts = ApiClient.api.shorts() }
    fun like(id: String) = call { ApiClient.api.like(id); loadFeed() }

    fun uploadVideo(context: Context, uri: Uri, title: String) = call {
        if (title.isBlank()) throw IllegalArgumentException("Title is required")
        status = "Creating upload session..."
        val session = ApiClient.api.uploadSession(UploadSessionRequest(title = title))
        status = "Uploading video..."
        val resolver = context.contentResolver
        val mime = resolver.getType(uri) ?: "video/mp4"
        val body = ContentUriRequestBody(context, uri, mime)
        val part = MultipartBody.Part.createFormData("video", "video.mp4", body)
        ApiClient.api.uploadVideo(session.videoId, part)
        status = "Upload complete"
        loadFeed()
    }

    fun suggestCaption(title: String, description: String, onResult: (String) -> Unit) = call {
        onResult(ai.suggestCaption(title, description))
    }

    fun logout() {
        Session.token = null
        Session.refreshToken = null
        loggedIn = false
        user = null
        videos = emptyList()
    }

    private fun call(block: suspend () -> Unit) {
        viewModelScope.launch {
            error = null
            try { block() } catch (t: Throwable) {
                error = t.message ?: "Request failed"
                status = null
            }
        }
    }
}

private class ContentUriRequestBody(
    private val context: Context,
    private val uri: Uri,
    private val mime: String
) : RequestBody() {
    override fun contentType() = mime.toMediaTypeOrNull()
    override fun contentLength(): Long = context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
    override fun writeTo(sink: BufferedSink) {
        context.contentResolver.openInputStream(uri)?.use { input ->
            input.source().use { source -> sink.writeAll(source) }
        } ?: throw IOException("Unable to open selected video")
    }
}

@Composable
fun NexaVideoApp(vm: AppViewModel = viewModel()) {
    if (vm.loggedIn) MainShell(vm) else Login(vm)
}

@Composable
fun Login(vm: AppViewModel) {
    var register by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 600.dp
        Column(
            Modifier
                .fillMaxSize()
                .padding(if (wide) 48.dp else 24.dp)
                .widthIn(max = 560.dp)
                .focusGroup(),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "NexaVideo",
                style = MaterialTheme.typography.headlineLarge,
                modifier = Modifier.semantics { heading() }
            )
            Text("Video • Shorts • Creators • Community")
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("Username / Email") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
            )
            Spacer(Modifier.height(8.dp))
            if (register) {
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
                Spacer(Modifier.height(8.dp))
            }
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password (8+ characters)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { if (register) vm.register(username, password, email.ifBlank { null }) else vm.login(username, password) },
                modifier = Modifier.fillMaxWidth().focusable(),
                enabled = username.isNotBlank() && password.isNotBlank()
            ) { Text(if (register) "Create account" else "Login") }
            TextButton(onClick = { register = !register }, modifier = Modifier.fillMaxWidth()) {
                Text(if (register) "Already have an account? Login" else "Create account")
            }
            vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.semantics { contentDescription = "Error: $it" }) }
        }
    }
}

@Composable
fun MainShell(vm: AppViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Home", "Shorts", "AI Studio", "Create", "Inbox", "Profile")
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, label ->
                    NavigationBarItem(
                        modifier = Modifier.semantics { contentDescription = "$label tab" },
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = {},
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        when (tab) {
            0 -> Home(vm, Modifier.padding(padding))
            1 -> Shorts(vm, Modifier.padding(padding))
            2 -> AiStudio(Modifier.padding(padding))
            3 -> Create(vm, Modifier.padding(padding))
            4 -> Inbox(Modifier.padding(padding))
            else -> Profile(vm, Modifier.padding(padding))
        }
    }
}

@Composable
fun Home(vm: AppViewModel, modifier: Modifier) {
    LaunchedEffect(Unit) { vm.loadFeed() }
    BoxWithConstraints(modifier.fillMaxSize()) {
        val contentPadding = if (maxWidth >= 600.dp) 32.dp else 16.dp
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = contentPadding).focusGroup()) {
        item {
            Text("For You", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() })
            Spacer(Modifier.height(12.dp))
        }
        items(vm.videos) { video ->
            Card(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(video.title, style = MaterialTheme.typography.titleLarge)
                    Text("@${video.username ?: "creator"} • ${video.views} views • ${video.likes} likes")
                    video.description?.let { Text(it, maxLines = 2) }
                    Row {
                        Button(onClick = { vm.like(video.id) }) { Text("Like") }
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = {}) { Text("Comments ${video.comments_count}") }
                    }
                }
            }
        }
        item { vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) } }
        }
    }
}

@Composable
fun Shorts(vm: AppViewModel, modifier: Modifier) {
    LaunchedEffect(Unit) { vm.loadShorts() }
    BoxWithConstraints(modifier.fillMaxSize()) {
        val contentPadding = if (maxWidth >= 600.dp) 32.dp else 16.dp
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = contentPadding).focusGroup()) {
        item { Text("Shorts", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() }) }
        items(vm.shorts) { short ->
            Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(short.title ?: "Untitled Short", style = MaterialTheme.typography.titleLarge)
                    Text("${short.views} views • ${short.duration_seconds ?: 0}s")
                    Text(short.video_url ?: "Video ready for playback")
                }
            }
        }
        }
    }
}


@Composable
fun AiStudio(modifier: Modifier) {
    val groups = listOf(
        "Video AI" to listOf("Auto Cut", "Smart Trim", "Highlight Maker", "Long Video → Shorts", "Scene Detection", "Auto Reframe", "Subject Tracking", "Background Remove/Replace", "Object Removal", "Video Enhancement", "Auto Captions", "Subtitle Translation"),
        "Generative Video" to listOf("Text → Video", "Image → Video", "Script → Storyboard", "AI B-roll", "Scene Extension", "Video Restyle"),
        "Design AI" to listOf("AI Image Generator", "Thumbnail Generator", "Poster Generator", "Banner Generator", "Background Generator", "Object Eraser", "Image Upscale", "Smart Crop"),
        "Audio & Voice AI" to listOf("Speech → Text", "Text → Speech", "AI Voice-over", "Voice Cleanup", "Noise Removal", "AI Dubbing", "Music Suggestions"),
        "Writing AI" to listOf("Script Writer", "Hook Generator", "Caption Generator", "Title Generator", "Hashtag Generator", "Translation", "Summarizer", "Comment Reply Assistant"),
        "Creator Intelligence" to listOf("Content Ideas", "Creator Copilot", "Audience Insights", "Retention Suggestions", "Upload Optimization"),
        "Safety AI" to listOf("Spam Detection", "Toxicity Detection", "Content Safety Scan", "Abuse Signals", "Comment Moderation")
    )
    LazyColumn(modifier.fillMaxSize().padding(16.dp).focusGroup()) {
        item {
            Text("Nexa AI Studio", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() })
            Text("Video editing • Design • Audio • Generative AI • Creator tools")
            Spacer(Modifier.height(12.dp))
        }
        groups.forEach { (title, tools) ->
            item { Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp)) }
            items(tools) { tool ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(tool)
                        Text("AI", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(12.dp))
            Text("AI provider connection is designed as a secure backend boundary. Actual generation requires configured AI providers, media workers and storage.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun Create(vm: AppViewModel, modifier: Modifier) {
    var title by remember { mutableStateOf("") }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> selectedUri = uri }

    var description by remember { mutableStateOf("") }
    var aiSuggestion by remember { mutableStateOf("") }
    var dragHint by remember { mutableStateOf("") }

    Column(
        modifier.padding(24.dp).pointerInput(Unit) {
            detectDragGestures(
                onDragEnd = { dragHint = "Drop a video from a supported desktop/file app above the picker." },
                onDrag = { _, _ -> }
            )
        }
    ) {
        Text("Create", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() })
        Text("AI-ready creator tools", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(title, { title = it }, label = { Text("Video title") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(description, { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { vm.suggestCaption(title, description) { aiSuggestion = it } },
            enabled = title.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Suggest caption") }
        if (aiSuggestion.isNotBlank()) {
            Text("Suggested: $aiSuggestion", modifier = Modifier.padding(vertical = 8.dp))
        }
        if (dragHint.isNotBlank()) Text(dragHint, modifier = Modifier.padding(vertical = 4.dp))
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { picker.launch(ActivityResultContracts.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
            modifier = Modifier.fillMaxWidth().focusable()
        ) {
            Text(if (selectedUri == null) "Choose video" else "Video selected")
        }
        Spacer(Modifier.height(8.dp))
        Button(
            enabled = selectedUri != null && title.isNotBlank(),
            onClick = { selectedUri?.let { vm.uploadVideo(context, it, title) } },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Upload to NexaVideo") }
        vm.status?.let { Text(it) }
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(8.dp))
        Text("AI provider boundary is ready; the current caption suggestion is local and does not call an external AI service. Production AI can be connected later with a provider key.")
    }
}

@Composable
fun Inbox(modifier: Modifier) {
    Column(modifier.padding(24.dp)) {
        Text("Inbox", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Text("Messaging API foundation is available. Conversation UI will be expanded in Step 2.")
    }
}

@Composable
fun Profile(vm: AppViewModel, modifier: Modifier) {
    Column(modifier.padding(24.dp)) {
        Text(vm.user?.display_name ?: vm.user?.username ?: "Profile", style = MaterialTheme.typography.headlineMedium)
        Text(vm.user?.email ?: "")
        Spacer(Modifier.height(16.dp))
        Button(onClick = { vm.logout() }) { Text("Logout") }
        Spacer(Modifier.height(8.dp))
        Text("Creator Studio • Earnings • Settings • Safety")
    }
}
