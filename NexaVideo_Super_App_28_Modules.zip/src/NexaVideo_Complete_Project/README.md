# NexaVideo — Professional Edition

NexaVideo is an original Android-first short-video and social platform project. This package is organized as a professional development codebase: mobile app, backend API, PostgreSQL data layer, Docker infrastructure, CI build, security hardening, QA checklists, and production integration documentation.

## Current status
**Stage:** Integrated MVP / production-preparation foundation

The project is designed to be developed and controlled by the owner. It is not presented as an already-live public service. Cloud accounts, production credentials, real media infrastructure, payments, push notifications, domain/TLS, and Play Store release still require owner-controlled external setup.

## Repository structure

- `android/` — Android / Jetpack Compose application
- `backend/` — Node.js + Express REST API
- `database/` — PostgreSQL schema
- `infrastructure/` — Docker Compose infrastructure
- `documentation/` — product, architecture, QA and release documentation
- `mobile_docs/` — mobile testing notes
- `tests/` — validation and smoke-test scripts
- `.github/workflows/` — CI build workflow

## Product foundation

- Authentication: register, login, refresh token, current user
- Home feed and creator content
- Shorts
- Video upload session and upload endpoint
- Likes and comments
- Follow / unfollow
- Saved videos
- Profiles
- Search and suggestions
- Notifications
- Direct messaging foundation
- Creator statistics and monetization data model
- Reporting and moderation foundation
- Admin health/report endpoints
- PostgreSQL relational data model
- Dockerized local development
- Release cleartext-HTTP hardening
- Production CORS hardening
- Production JWT secret validation

## Local development

### Backend

1. Install Docker Desktop.
2. Open a terminal in `infrastructure/`.
3. Run:

```bash
docker compose up --build
```

4. Check:

`http://localhost:8080/health`

Expected healthy response includes `ok: true` and database `ok`.

### Android

1. Install Android Studio and JDK 17.
2. Open the `android/` directory.
3. Allow Gradle Sync to finish.
4. Start an Android emulator.
5. Run the app.
6. Emulator API base is `http://10.0.2.2:8080/`.

For a physical phone, use a reachable laptop LAN address during local development or an HTTPS production API URL.

## Before public launch

The owner must configure and verify:

- Cloud hosting and HTTPS
- Managed PostgreSQL and backups
- Object storage + CDN
- Real video transcoding/processing
- Push notifications
- Email/SMS verification
- Payment and creator payout provider
- Production secrets management
- Monitoring and logging
- Moderation operations
- Privacy Policy and Terms
- Signed release build and Play Console
- Load/reliability/security testing

## Professional development rule

Keep source code, cloud accounts, domain, database, storage, Firebase, payment accounts and release signing credentials under the owner's control. Never commit `.env` files, passwords, API keys or release keystores to Git.

See `documentation/PROFESSIONAL_PROJECT_GUIDE.md` for the full build-to-launch workflow.
