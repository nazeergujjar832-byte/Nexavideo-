# NexaVideo API Overview

Base path: `/api/v1`

## Authentication
- `POST /auth/register`
- `POST /auth/login`
- `POST /auth/refresh`
- `GET /me`

## Feed and video
- `GET /feed`
- `POST /videos/upload-session`
- `POST /videos/:id/upload`
- `POST /videos/:id/view`
- `POST /videos/:id/watch`
- `POST /videos/:id/like`
- `DELETE /videos/:id/like`
- `GET /videos/:id/comments`
- `POST /videos/:id/comments`
- `POST /videos/:id/save`
- `DELETE /videos/:id/save`
- `GET /me/saved`

## Shorts
- `GET /shorts`
- `POST /shorts/:id/view`

## Social
- `POST /users/:id/follow`
- `DELETE /users/:id/follow`
- `GET /notifications`
- `POST /notifications/read-all`
- `GET /messages/:userId`
- `POST /messages/:userId`

## Search
- `GET /search`
- `GET /search/suggestions`

## Creator
- `GET /creator/stats`
- `POST /creator/enable`

## Safety/admin
- `POST /reports`
- `GET /admin/reports`
- `PATCH /admin/reports/:id`
- `GET /admin/health`

## Health
- `GET /health`
- `GET /api/v1/health/details`
