# NexaVideo QA Test Plan

## Smoke test
- [ ] API starts
- [ ] PostgreSQL connects
- [ ] `/health` returns healthy
- [ ] Android app launches
- [ ] Register succeeds
- [ ] Login succeeds
- [ ] Feed loads
- [ ] Shorts load

## Core user journey
- [ ] Create account
- [ ] Edit profile
- [ ] Upload a video
- [ ] Video appears in feed after ready state
- [ ] Like/unlike
- [ ] Add comment
- [ ] Follow/unfollow creator
- [ ] Save/unsave video
- [ ] Search creator/video
- [ ] Send message
- [ ] Receive notification

## Safety
- [ ] Invalid token rejected
- [ ] Non-admin cannot access admin endpoints
- [ ] Invalid request body rejected
- [ ] Oversized upload rejected
- [ ] Non-video upload rejected
- [ ] Production CORS checked
- [ ] Production HTTP cleartext disabled

## Release regression
- [ ] Release build compiles
- [ ] Signed build installs
- [ ] Production API uses HTTPS
- [ ] Secrets are externalized
- [ ] Database backup verified
- [ ] Monitoring verified
