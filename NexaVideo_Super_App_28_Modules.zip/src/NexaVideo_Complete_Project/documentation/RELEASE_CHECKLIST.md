# NexaVideo Release Checklist

## Development
- [ ] Local API healthy
- [ ] Database migrations/schema verified
- [ ] Android debug build verified
- [ ] End-to-end tests passed

## Production
- [ ] HTTPS/domain active
- [ ] Managed PostgreSQL active
- [ ] Object storage active
- [ ] CDN configured
- [ ] Video transcoding configured
- [ ] Push notifications configured
- [ ] Email/SMS configured
- [ ] Payment/payout provider configured
- [ ] Monitoring/logging active
- [ ] Backups tested

## Security
- [ ] Strong secrets generated
- [ ] CORS origins restricted
- [ ] No secrets committed
- [ ] Release cleartext disabled
- [ ] Admin access reviewed
- [ ] Abuse/reporting process tested

## Store release
- [ ] Release keystore backed up securely
- [ ] AAB signed
- [ ] App icon/branding finalized
- [ ] Privacy policy published
- [ ] Terms published
- [ ] Store listing prepared
- [ ] Internal testing completed
