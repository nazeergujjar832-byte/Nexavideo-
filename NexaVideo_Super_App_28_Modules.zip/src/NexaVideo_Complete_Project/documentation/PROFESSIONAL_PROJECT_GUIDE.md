# NexaVideo — Professional Project Guide

## 1. Product goal
NexaVideo is an original short-video and social platform. The product is being built as a real software product rather than a demo-only interface. The current codebase provides the core mobile, API and database foundation required for continued development.

## 2. Product layers

### Mobile
Jetpack Compose Android application with authentication, feed, Shorts, create/upload, inbox and profile flows.

### API
Node.js + Express REST API under `/api/v1` with authentication, validation, rate limiting, social features, video operations, creator data and moderation endpoints.

### Data
PostgreSQL stores users, profiles, videos, shorts, follows, likes, comments, saved videos, notifications, messages, creator records, reports, audit records and analytics-related data.

### Infrastructure
Docker Compose provides local PostgreSQL and API services. CI provides a repeatable Android debug build.

## 3. Professional workflow

1. Local environment setup.
2. Database/API health check.
3. Android build and emulator test.
4. End-to-end feature testing.
5. Bug fixing and regression testing.
6. Production infrastructure selection.
7. Security and secrets configuration.
8. Media storage/CDN/transcoding integration.
9. Notifications, verification and payments integration.
10. Release signing and store preparation.
11. Staged launch and monitoring.

## 4. Quality gates

A feature is not considered complete until it has:
- API validation
- database behavior verified
- Android UI tested
- loading/error states handled
- authentication/authorization checked
- regression test performed

## 5. Security baseline

- HTTPS in production
- explicit CORS origins
- strong production JWT/refresh secrets
- rate limiting
- request validation with Zod
- Helmet security headers
- password hashing with bcrypt
- no secrets in source control
- release cleartext HTTP disabled
- audit logging foundation
- moderation/reporting foundation

## 6. Media architecture

The current local upload flow is suitable for development. Public production should move large media to object storage and use a CDN plus a real transcoding pipeline. Playback should use delivery URLs rather than depending on local container storage.

## 7. Creator and earning architecture

The database already includes creator accounts, earnings ledger, creator payouts and advertising data structures. A production monetization system still requires a verified payment provider, payout rules, fraud controls, accounting reconciliation and legal/compliance review.

## 8. Owner control

The owner should keep control of source code, Git repository, cloud accounts, domain, database, storage, Firebase, payment provider, signing keys and Play Console. External developers can be granted limited access without transferring ownership.

## 9. Release definition

A public release should only happen after local end-to-end tests pass, production services are configured, secrets are protected, the release build is signed, privacy/terms are published, and monitoring/rollback procedures exist.
