# NexaVideo Launch Readiness

## Included and working in this package
- Android Jetpack Compose app with Login/Register, Home feed, Shorts, Create, Inbox and Profile shells.
- Retrofit API client with bearer authentication.
- PostgreSQL schema covering users, profiles, videos, shorts, social graph, comments, messaging, notifications, creator ledger and moderation/audit tables.
- Docker Compose for PostgreSQL + API with health checks.
- Video upload endpoint with MIME validation, persistent upload volume, public playback URL, and READY status for MVP/local deployment.
- CI workflow that builds an Android APK with a configurable API base URL.
- Production JWT secret validation, Helmet, CORS, rate limiting and request validation.

## Still required before a public store launch
These cannot be completed inside a source ZIP without external accounts/infrastructure: a real HTTPS domain, hosted PostgreSQL, object storage/CDN, transcoding pipeline, FCM credentials, email/SMS provider, payment/payout provider, Play Console account, release keystore, privacy/terms URLs, moderation operations and load/security testing.

## Mobile test
For emulator/local Docker: build with `-PAPI_BASE_URL=http://10.0.2.2:8080/`. For a physical phone, replace it with the reachable HTTPS/LAN API URL.
