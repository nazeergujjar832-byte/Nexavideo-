# NexaVideo AI Studio

NexaVideo now includes a dedicated AI Studio product surface and a provider-neutral AI tool catalog.

The catalog covers video editing, generative video, image/design, audio/voice, writing, creator intelligence and safety AI.

The Android app exposes the AI Studio categories. The backend exposes `/api/v1/ai/tools` and a provider-safe `/api/v1/ai/jobs` boundary.

Important: adding a tool to the product architecture does not magically provide the underlying AI model. Production generation requires selecting providers/models, securely storing server-side credentials, media workers, object storage/CDN, queues, usage limits and privacy/moderation controls.
