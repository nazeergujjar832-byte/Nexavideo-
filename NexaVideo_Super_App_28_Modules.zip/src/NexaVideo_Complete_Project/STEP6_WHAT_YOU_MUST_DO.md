# NexaVideo — What You Must Do Next

The source project is consolidated. The remaining work requires accounts, credentials, a computer, or real external infrastructure and therefore cannot be completed inside the source package alone.

## 1. Local test first
- Install Android Studio, JDK 17 and Docker Desktop.
- Start `infrastructure/docker-compose.yml`.
- Check `http://localhost:8080/health`.
- Open `android/` in Android Studio and run on an emulator or phone.
- For an Android emulator, use `http://10.0.2.2:8080/` as the API base URL.

## 2. Production accounts you must create
- Cloud/server hosting
- Managed PostgreSQL or a secured production PostgreSQL server
- Object storage + CDN + video transcoding
- Firebase/FCM
- Email/SMS verification provider
- Payment/payout provider
- Domain + HTTPS certificate
- Google Play Console

## 3. Secrets
Never commit real passwords, JWT secrets, payment keys, FCM keys or signing keys to Git. Use environment variables or a secret manager.

## 4. Release
Before a public release, run the full end-to-end test: registration, login, feed, Shorts, upload/playback, likes/comments/follows/saves, chat, notifications, creator features, reports/admin and failure/recovery cases.

## 5. Current source protections
Production startup now rejects weak JWT/refresh secrets and wildcard CORS. Android release builds disable cleartext HTTP by default; debug builds allow it for local emulator testing.
