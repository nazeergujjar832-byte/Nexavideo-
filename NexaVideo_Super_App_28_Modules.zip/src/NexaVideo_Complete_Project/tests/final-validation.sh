#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

node --check backend/src/server.js
printf '%s\n' "Backend syntax: OK"

if command -v docker >/dev/null 2>&1; then
  docker compose -f infrastructure/docker-compose.yml config >/dev/null
  printf '%s\n' "Docker Compose config: OK"
else
  printf '%s\n' "Docker not installed; skipped Docker config check"
fi
