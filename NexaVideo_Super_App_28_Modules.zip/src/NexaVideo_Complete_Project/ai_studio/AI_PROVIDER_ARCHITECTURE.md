# Nexa AI Provider Architecture

## Rule
Provider API keys never belong in the Android application. The Android client calls NexaVideo's backend; the backend validates the request, creates an AI job, sends it to the configured provider/worker, stores results, and returns job status.

## Job lifecycle
1. Client selects a tool.
2. Backend validates tool + input.
3. Backend creates an AI job.
4. Worker/provider processes the job.
5. Output is stored in object storage.
6. Job status becomes completed/failed.
7. Client receives the result and can edit/publish it.

## Future provider categories
- LLM/text provider
- Image generation provider
- Video generation provider
- Speech-to-text provider
- Text-to-speech provider
- Translation provider
- Vision/moderation provider
- Media processing/transcoding worker

## Production requirements
Object storage, queue/worker system, CDN, GPU/media workers where required, usage limits, billing controls, audit logs, moderation and privacy controls must be added before public AI generation is enabled.
