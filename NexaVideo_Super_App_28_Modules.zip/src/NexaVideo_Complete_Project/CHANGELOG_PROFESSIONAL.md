# NexaVideo Professional Edition — Changelog

## 1.1.0
- Reorganized project documentation around a professional product workflow.
- Added professional architecture, API overview, QA plan and release checklist.
- Removed a temporary backend source artifact from the package.
- Updated Android version to 1.1.0 / versionCode 6.
- Preserved production CORS hardening and release cleartext-HTTP hardening.

## 1.0.0
- Consolidated Android, backend, PostgreSQL and Docker foundations.
- Added authentication, feed, Shorts, uploads, social, messaging, creator and moderation foundations.
